import { supabase } from './supabase';
import type { CartItem, ContactMessage, OrderDetails } from '../types';

export interface ApiResponse {
  success: boolean;
  message?: string;
  orderId?: string;
  error?: string;
}

export async function submitOrder(
  orderDetails: OrderDetails,
  cartItems: CartItem[],
  subtotal: number,
  shipping: number,
  total: number
): Promise<ApiResponse> {
  try {
    console.log('Submitting order to Supabase...', { orderDetails, cartItems, subtotal, shipping, total });

    const { data, error } = await supabase
      .from('orders')
      .insert({
        email: orderDetails.email,
        phone: orderDetails.phone,
        delivery_date: orderDetails.deliveryDate,
        delivery_time: orderDetails.deliveryTime,
        city: orderDetails.city,
        address: orderDetails.address,
        notes: orderDetails.notes || '',
        payment_method: orderDetails.paymentMethod,
        cart_items: cartItems,
        subtotal,
        shipping,
        total,
        status: 'pending'
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      throw error;
    }

    console.log('Order submitted successfully:', data);

    return {
      success: true,
      message: 'ההזמנה נשלחה בהצלחה',
      orderId: data.id
    };
  } catch (error) {
    console.error('Error submitting order:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'שגיאה בשליחת ההזמנה'
    };
  }
}

export async function submitContact(contactData: ContactMessage): Promise<ApiResponse> {
  try {
    console.log('Submitting contact to Supabase...', contactData);

    const { data, error } = await supabase
      .from('contacts')
      .insert({
        name: contactData.name,
        phone: contactData.phone,
        email: contactData.email || '',
        preferred_date: contactData.preferred_date || '',
        preferred_time: contactData.preferred_time || '',
        message: contactData.message,
        status: 'new'
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      throw error;
    }

    console.log('Contact submitted successfully:', data);

    return {
      success: true,
      message: 'ההודעה נשלחה בהצלחה'
    };
  } catch (error) {
    console.error('Error submitting contact:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'שגיאה בשליחת ההודעה'
    };
  }
}

export async function submitReview(
  name: string,
  email: string,
  rating: number,
  reviewHe: string,
  reviewEn: string
): Promise<ApiResponse> {
  try {
    console.log('Submitting review to Supabase...', { name, email, rating, reviewHe, reviewEn });

    const { data, error } = await supabase
      .from('reviews')
      .insert({
        name,
        email: email || '',
        rating,
        review_he: reviewHe,
        review_en: reviewEn || '',
        status: 'pending',
        is_visible: false
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase error:', error);
      throw error;
    }

    console.log('Review submitted successfully:', data);

    return {
      success: true,
      message: 'ההמלצה נשלחה בהצלחה'
    };
  } catch (error) {
    console.error('Error submitting review:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'שגיאה בשליחת ההמלצה'
    };
  }
}
