import type { DeliveryArea } from '../types';

export const deliveryAreas: DeliveryArea[] = [
  {
    city: 'ירושלים',
    streets: [
      'הרצל',
      'יפו',
      'בן יהודה',
      'קינג ג\'ורג\'',
      'אגריפס',
      'שמאי',
      'הלל',
      'ממילא',
      'נחלת שבעה',
      'בצלאל',
      'כנפי נשרים',
      'דרך בית לחם',
      'עמק רפאים',
      'פיירברג',
      'רמב"ן',
      'רמב"ם',
      'אבן עזרא',
      'חברון',
      'מלכי ישראל',
      'שמואל הנביא',
      'בר אילן',
      'גולומב',
      'שדרות הרצל',
      'יפה נוף',
      'בית הכרם',
      'קטמון',
      'רחביה',
      'טלביה',
      'הרי"ף',
      'ז\'בוטינסקי',
      'בן מימון',
      'עזה',
      'הנביאים',
      'חנקין',
      'כרם אברהם',
      'נחליאל',
      'גאולה',
      'מאה שערים',
      'בוכרים',
      'נחלאות',
      'מחנה יהודה',
      'רוממה',
      'קריית וולפסון',
      'קרית יובל',
      'עיר גנים',
      'גבעת שאול',
      'גבעת מרדכי',
      'גבעת משואה',
      'נווה יעקב',
      'פסגת זאב',
      'רמות',
      'רמת אשכול',
      'רמת שרת',
      'רמת דניה',
      'גילה',
      'תלפיות',
      'ארנונה',
      'גונן',
      'בקעה'
    ]
  },
  {
    city: 'מבשרת ציון',
    streets: [
      'הרצל',
      'בן גוריון',
      'ז\'בוטינסקי',
      'רוטשילד',
      'ויצמן',
      'הנשיא',
      'האלון',
      'הדקל',
      'הזית',
      'הרימון',
      'התמר',
      'הערבה',
      'הצבר',
      'האלה',
      'השקד',
      'האורן',
      'הברוש',
      'הארז',
      'הדולב',
      'הכרמל',
      'הגלבוע',
      'החרמון',
      'הגלעד',
      'התבור',
      'המוריה',
      'הסנה',
      'השיטה',
      'הרקפת',
      'הצבעוני',
      'הכלנית',
      'הנרקיס',
      'היסמין',
      'הורד',
      'הסייפן',
      'הגפן',
      'הזמיר',
      'היונה',
      'הדרור',
      'העפרוני',
      'החסידה',
      'הנחליאלי',
      'הדוכיפת',
      'הבז',
      'הנשר',
      'השחף',
      'הפלמינגו'
    ]
  }
];

function normalizeString(str: string): string {
  return str
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/['"״׳`]/g, '')
    .replace(/[\u0591-\u05C7]/g, '');
}

export function isValidDeliveryAddress(city: string, street: string): boolean {
  const normalizedCity = city.trim();
  const normalizedStreet = normalizeString(street);

  if (!normalizedStreet || normalizedStreet.length < 2) return false;

  const area = deliveryAreas.find(a => a.city === normalizedCity);
  if (!area) return false;

  return area.streets.some(s => {
    const normalizedAreaStreet = normalizeString(s);

    if (normalizedAreaStreet === normalizedStreet) return true;

    if (normalizedAreaStreet.includes(normalizedStreet)) return true;

    if (normalizedStreet.includes(normalizedAreaStreet)) return true;

    const streetWords = normalizedStreet.split(' ').filter(w => w.length > 1);
    const areaWords = normalizedAreaStreet.split(' ').filter(w => w.length > 1);

    if (streetWords.length === 0 || areaWords.length === 0) return false;

    const matchCount = streetWords.filter(word =>
      areaWords.some(areaWord =>
        areaWord.includes(word) ||
        word.includes(areaWord) ||
        (word.length > 2 && areaWord.length > 2 &&
         (areaWord.startsWith(word.substring(0, 3)) || word.startsWith(areaWord.substring(0, 3))))
      )
    ).length;

    return matchCount >= Math.max(1, Math.floor(streetWords.length / 2));
  });
}

export function getAvailableCities(): string[] {
  return deliveryAreas.map(area => area.city);
}

export function getStreetsForCity(city: string): string[] {
  const area = deliveryAreas.find(a => a.city === city);
  return area ? area.streets : [];
}

export function getStreetSuggestions(city: string, query: string): string[] {
  if (!query || query.length < 2) return [];

  const streets = getStreetsForCity(city);
  const normalizedQuery = normalizeString(query);

  const exactMatches: string[] = [];
  const startsWith: string[] = [];
  const contains: string[] = [];
  const wordMatches: string[] = [];

  streets.forEach(street => {
    const normalizedStreet = normalizeString(street);

    if (normalizedStreet === normalizedQuery) {
      exactMatches.push(street);
    } else if (normalizedStreet.startsWith(normalizedQuery)) {
      startsWith.push(street);
    } else if (normalizedStreet.includes(normalizedQuery)) {
      contains.push(street);
    } else {
      const queryWords = normalizedQuery.split(' ').filter(w => w.length > 1);
      const streetWords = normalizedStreet.split(' ').filter(w => w.length > 1);

      const hasMatch = queryWords.some(qWord =>
        streetWords.some(sWord =>
          sWord.includes(qWord) || qWord.includes(sWord) ||
          (qWord.length > 2 && sWord.length > 2 && sWord.startsWith(qWord.substring(0, 3)))
        )
      );

      if (hasMatch) {
        wordMatches.push(street);
      }
    }
  });

  return [...exactMatches, ...startsWith, ...contains, ...wordMatches].slice(0, 15);
}
