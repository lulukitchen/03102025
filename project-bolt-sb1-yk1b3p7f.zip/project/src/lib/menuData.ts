import type { MenuItem } from '../types';

const CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRFmGECEXCaaH6uXJ_lDHO7g1GaIwh-aHTy9P_EVoTYWxROaBOa_XPJ4H3OOe4h4NwlU93Lg-_au-2B/pub?gid=1874715002&single=true&output=csv';

export async function fetchMenuFromCSV(): Promise<MenuItem[]> {
  try {
    const response = await fetch(CSV_URL);
    const csvText = await response.text();

    const lines = csvText.split('\n');
    const headers = lines[0].split(',').map(h => h.trim());

    const menuItems: MenuItem[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue;

      const values = parseCSVLine(line);
      if (values.length < 2) continue;

      const item: Partial<MenuItem> = {
        id: '',
        available: true,
        sort_order: i,
        is_vegetarian: false,
        is_vegan: false,
      };

      headers.forEach((header, index) => {
        const value = values[index]?.trim() || '';

        switch (header.toLowerCase()) {
          case 'id':
            item.id = value || crypto.randomUUID();
            break;
          case 'name_he':
            item.name_he = value;
            break;
          case 'name_en':
            item.name_en = value;
            break;
          case 'description_he':
            item.description_he = value;
            break;
          case 'description_en':
            item.description_en = value;
            break;
          case 'price':
            item.price = parseFloat(value.replace(/[^0-9.]/g, '')) || 0;
            break;
          case 'category_he':
            break;
          case 'category_en':
            item.category = value.toLowerCase() || 'other';
            break;
          case 'portion_size':
            item.portion_size = value;
            break;
          case 'vegetarian':
            item.is_vegetarian = value.toLowerCase() === 'כן' || value.toLowerCase() === 'yes';
            break;
          case 'vegan':
            item.is_vegan = value.toLowerCase() === 'כן' || value.toLowerCase() === 'yes';
            break;
          case 'image_url':
            item.image_url = value;
            break;
          case 'allergens':
            item.allergens = value;
            break;
          case 'availability_status':
            item.available = value !== 'לא זמין' && value.toLowerCase() !== 'unavailable';
            break;
          case 'display_order':
            const order = parseInt(value);
            if (!isNaN(order)) {
              item.sort_order = order;
            }
            break;
        }
      });

      if (!item.id) {
        item.id = crypto.randomUUID();
      }

      if (item.name_he && item.name_en && item.price) {
        menuItems.push(item as MenuItem);
      }
    }

    return menuItems.sort((a, b) => a.sort_order - b.sort_order);
  } catch (error) {
    console.error('Error fetching menu from CSV:', error);
    return getHardcodedMenuItems();
  }
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }

  result.push(current);
  return result;
}

function getHardcodedMenuItems(): MenuItem[] {
  return [
    {
      id: '1',
      name_he: 'גו טיאר מטוגן (בשר ובצל/גזר)',
      name_en: 'Go Tiar Fried Dumplings (Beef & Onion/Carrot)',
      description_he: 'וריאציה מטוגנת לגיוזה: כופתאות מטוגנות במילוי בשר בקר טחון ובצל או גזר. ניתן לבחור בשר ובצל או בשר וגזר. כ-15 יחידות.',
      description_en: 'Fried variation of gyoza: dumplings filled with minced beef and onions or carrot. About 15 pcs.',
      price: 48,
      category: 'other',
      is_vegetarian: false,
      is_vegan: false,
      available: true,
      sort_order: 1,
    },
    {
      id: '2',
      name_he: "ג'יאוזה בשר וכוסברה",
      name_en: 'Jiaoza Beef & Coriander',
      description_he: 'כיסונים בעבודת יד עם בשר וכוסברה. מנה סינית מסורתית. כ-15 יחידות.',
      description_en: 'Handmade dumplings with beef & coriander, traditional.',
      price: 45,
      category: 'other',
      is_vegetarian: false,
      is_vegan: false,
      available: true,
      sort_order: 2,
    },
    {
      id: '3',
      name_he: "צ'או מיאן עוף וירקות",
      name_en: 'Chow Mian Chicken & Veg',
      description_he: 'נודלס מוקפץ עם חזה עוף, גזר, כרוב, פטריות וביצים. אפשרות איטריות ביצים/אורז.',
      description_en: 'Stir-fried noodles with chicken breast, carrots, cabbage, mushrooms, eggs.',
      price: 52,
      category: 'other',
      is_vegetarian: false,
      is_vegan: false,
      available: true,
      sort_order: 3,
    },
    {
      id: '4',
      name_he: 'באודזה ירקות וטופו מאודה',
      name_en: 'Baozi Steamed Veg & Tofu',
      description_he: 'כיסונים מאודים עם ירקות, טופו ובצל. לפחות 5 יחידות, 100% עבודת יד.',
      description_en: 'Steamed dumplings with vegetables, tofu and onion, min 5 pcs.',
      price: 44,
      category: 'other',
      is_vegetarian: true,
      is_vegan: true,
      available: true,
      sort_order: 4,
    },
    {
      id: '5',
      name_he: 'אורז מוקפץ ירקות',
      name_en: 'Fried Rice & Veggies',
      description_he: 'אורז מוקפץ עם גזר, אפונה, תירס, פטריות וביצים.',
      description_en: 'Fried rice with carrots, peas, corn, mushrooms and eggs.',
      price: 32,
      category: 'other',
      is_vegetarian: true,
      is_vegan: false,
      available: true,
      sort_order: 5,
    },
  ];
}
