import { useEffect, useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Cart from './components/Cart';
import OrderForm from './components/OrderForm';
import OrderConfirmation from './components/OrderConfirmation';
import ExitIntentPopup from './components/ExitIntentPopup';
import Home from './pages/Home';
import Menu from './pages/Menu';
import About from './pages/About';
import Reviews from './pages/Reviews';
import Contact from './pages/Contact';
import { LanguageProvider } from './hooks/useLanguage';
import { CartProvider } from './hooks/useCart';
import type { OrderDetails } from './types';

function Router() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);

  useEffect(() => {
    const handleNavigation = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handleNavigation);

    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a');

      if (link && link.href && link.host === window.location.host) {
        e.preventDefault();
        window.history.pushState({}, '', link.href);
        setCurrentPath(link.pathname);
        window.scrollTo(0, 0);
      }
    });

    return () => {
      window.removeEventListener('popstate', handleNavigation);
    };
  }, []);

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsOrderFormOpen(true);
  };

  const handleOrderSubmit = (details: OrderDetails) => {
    setOrderDetails(details);
    setIsOrderFormOpen(false);
    setIsConfirmationOpen(true);
  };

  const handleConfirmationClose = () => {
    setIsConfirmationOpen(false);
    setOrderDetails(null);
  };

  let PageComponent;

  switch (currentPath) {
    case '/menu':
      PageComponent = Menu;
      break;
    case '/about':
      PageComponent = About;
      break;
    case '/reviews':
      PageComponent = Reviews;
      break;
    case '/contact':
      PageComponent = Contact;
      break;
    default:
      PageComponent = Home;
  }

  return (
    <>
      <Header onCartClick={() => setIsCartOpen(true)} />
      <main>
        <PageComponent />
      </main>
      <Footer />
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={handleCheckout}
      />
      <OrderForm
        isOpen={isOrderFormOpen}
        onClose={() => setIsOrderFormOpen(false)}
        onSubmit={handleOrderSubmit}
      />
      {orderDetails && (
        <OrderConfirmation
          isOpen={isConfirmationOpen}
          orderDetails={orderDetails}
          onClose={handleConfirmationClose}
        />
      )}
      <ExitIntentPopup onViewCart={() => setIsCartOpen(true)} />
    </>
  );
}

function App() {
  return (
    <LanguageProvider>
      <CartProvider>
        <div className="min-h-screen bg-gray-50">
          <Router />
        </div>
      </CartProvider>
    </LanguageProvider>
  );
}

export default App;
