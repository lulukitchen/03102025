import { useEffect, useState } from 'react';
import { Star } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { useCart } from '../hooks/useCart';
import type { MenuItem } from '../types';

interface RecommendationsProps {
  allMenuItems: MenuItem[];
  onItemClick: (item: MenuItem) => void;
}

export default function Recommendations({ allMenuItems, onItemClick }: RecommendationsProps) {
  const { language, t } = useLanguage();
  const { cartItems } = useCart();
  const [recommendations, setRecommendations] = useState<MenuItem[]>([]);

  useEffect(() => {
    if (allMenuItems.length === 0) return;

    const cartItemIds = new Set(cartItems.map(item => item.menuItem.id));
    const cartCategories = new Set(cartItems.map(item => item.menuItem.category));

    let recommended: MenuItem[] = [];

    if (cartCategories.size > 0) {
      recommended = allMenuItems.filter(item =>
        !cartItemIds.has(item.id) &&
        cartCategories.has(item.category)
      );
    }

    if (recommended.length < 3) {
      const additional = allMenuItems.filter(item => !cartItemIds.has(item.id));
      recommended = [...recommended, ...additional];
    }

    const shuffled = recommended.sort(() => Math.random() - 0.5);
    setRecommendations(shuffled.slice(0, 3));
  }, [cartItems, allMenuItems]);

  if (recommendations.length === 0) return null;

  return (
    <div className="bg-gradient-to-br from-chinese-lightGold to-white p-6 rounded-2xl">
      <div className="flex items-center gap-2 mb-4">
        <Star className="w-6 h-6 text-chinese-gold fill-chinese-gold" />
        <h3 className="text-xl font-bold">
          {t('מומלץ במיוחד', 'Highly Recommended')}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {recommendations.map(item => (
          <div
            key={item.id}
            onClick={() => onItemClick(item)}
            className="bg-white rounded-lg p-4 cursor-pointer hover:shadow-lg transition-shadow"
          >
            {item.image_url && (
              <img
                src={item.image_url}
                alt={language === 'he' ? item.name_he : item.name_en}
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
            )}
            <h4 className="font-semibold mb-1">
              {language === 'he' ? item.name_he : item.name_en}
            </h4>
            <p className="text-sm text-gray-600 mb-2 line-clamp-2">
              {language === 'he' ? item.description_he : item.description_en}
            </p>
            <div className="flex justify-between items-center">
              <span className="text-lg font-bold text-chinese-red">₪{item.price}</span>
              <button className="text-sm text-chinese-red font-semibold hover:underline">
                {t('הוסף', 'Add')}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
