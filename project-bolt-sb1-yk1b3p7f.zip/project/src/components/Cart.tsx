import { ShoppingCart, X, Plus, Minus, Trash2 } from 'lucide-react';
import { useCart } from '../hooks/useCart';
import { useLanguage } from '../hooks/useLanguage';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

export default function Cart({ isOpen, onClose, onCheckout }: CartProps) {
  const { cartItems, updateQuantity, removeFromCart, getTotalPrice, getShippingCost, getTotalItems } = useCart();
  const { language, t } = useLanguage();

  if (!isOpen) return null;

  const subtotal = getTotalPrice();
  const shipping = getShippingCost();
  const total = subtotal + shipping;
  const freeShippingRemaining = 800 - subtotal;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={onClose} />
      <div className={`fixed top-0 ${language === 'he' ? 'right-0' : 'left-0'} h-full w-full max-w-md bg-white shadow-2xl z-50 transform transition-transform duration-300`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-6 h-6 text-chinese-red" />
              <h2 className="text-xl font-bold">
                {t('עגלת קניות', 'Shopping Cart')} ({getTotalItems()})
              </h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <X className="w-6 h-6" />
            </button>
          </div>

          {cartItems.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
              <ShoppingCart className="w-16 h-16 text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg">{t('העגלה ריקה', 'Your cart is empty')}</p>
              <button
                onClick={onClose}
                className="mt-4 px-6 py-2 bg-chinese-red text-white rounded-lg hover:bg-chinese-darkRed"
              >
                {t('המשך קניות', 'Continue Shopping')}
              </button>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto p-4">
                {freeShippingRemaining > 0 && (
                  <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800">
                      {t(
                        `הוסף עוד ₪${freeShippingRemaining.toFixed(2)} למשלוח חינם!`,
                        `Add ₪${freeShippingRemaining.toFixed(2)} more for free shipping!`
                      )}
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  {cartItems.map((item, index) => {
                    const itemTotal = (item.menuItem.price + item.selectedAddOns.reduce((sum, addon) => sum + addon.price, 0)) * item.quantity;
                    const imagesBase = import.meta.env.VITE_IMAGES_BASE || 'https://lulu-k.com/images';
                    const imageUrl = item.menuItem.image_url
                      ? `${imagesBase}/${item.menuItem.image_url}`
                      : null;

                    return (
                      <div key={`${item.menuItem.id}-${index}`} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex gap-3 mb-2">
                          {imageUrl && (
                            <img
                              src={imageUrl}
                              alt={language === 'he' ? item.menuItem.name_he : item.menuItem.name_en}
                              className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                              loading="lazy"
                              onError={(e) => {
                                (e.target as HTMLImageElement).style.display = 'none';
                              }}
                            />
                          )}
                          <div className="flex-1 flex justify-between items-start">
                            <h3 className="font-semibold">
                              {language === 'he' ? item.menuItem.name_he : item.menuItem.name_en}
                            </h3>
                            <button
                              onClick={() => removeFromCart(item.menuItem.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                        </div>

                        {item.selectedAddOns.length > 0 && (
                          <div className="text-sm text-gray-600 mb-2">
                            {item.selectedAddOns.map((addon, idx) => (
                              <div key={idx}>
                                + {language === 'he' ? addon.name_he : addon.name_en} (+₪{addon.price})
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.menuItem.id, item.quantity - 1)}
                              className="p-1 bg-white rounded hover:bg-gray-100"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center font-semibold">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.menuItem.id, item.quantity + 1)}
                              className="p-1 bg-white rounded hover:bg-gray-100"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          <span className="font-bold text-chinese-red">₪{itemTotal.toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="border-t p-4 bg-gray-50">
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-gray-600">
                    <span>{t('סכום ביניים', 'Subtotal')}</span>
                    <span>₪{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>{t('משלוח', 'Shipping')}</span>
                    <span className={shipping === 0 ? 'text-green-600 font-semibold' : ''}>
                      {shipping === 0 ? t('חינם!', 'Free!') : `₪${shipping.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-xl font-bold pt-2 border-t">
                    <span>{t('סה"כ', 'Total')}</span>
                    <span className="text-chinese-red">₪{total.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  onClick={onCheckout}
                  className="w-full py-3 bg-chinese-red text-white rounded-lg font-semibold hover:bg-chinese-darkRed transition-colors"
                >
                  {t('המשך לתשלום', 'Proceed to Checkout')}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
