import { CheckCircle } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { useCart } from '../hooks/useCart';
import type { OrderDetails } from '../types';

interface OrderConfirmationProps {
  isOpen: boolean;
  orderDetails: OrderDetails;
  onClose: () => void;
}

export default function OrderConfirmation({ isOpen, orderDetails, onClose }: OrderConfirmationProps) {
  const { t } = useLanguage();
  const { clearCart } = useCart();

  if (!isOpen) return null;

  const handlePayment = () => {
    if (orderDetails.paymentMethod === 'bit') {
      window.open('https://www.bitpay.co.il/app/me/C822FDFE-1C69-4F92-B57B-09635D465B9D', '_blank');
    } else if (orderDetails.paymentMethod === 'paybox') {
      window.open('https://link.payboxapp.com/Hh5KZaqQc1Jz93Zv7', '_blank');
    }
    clearCart();
    onClose();
  };

  const handleClose = () => {
    clearCart();
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={onClose} />
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <div className="flex min-h-full items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8 text-center">
            <div className="flex justify-center mb-6">
              <CheckCircle className="w-20 h-20 text-green-500" />
            </div>

            <h2 className="text-2xl font-bold mb-4">
              {t('ההזמנה התקבלה בהצלחה!', 'Order Received Successfully!')}
            </h2>

            <div className="text-right bg-gray-50 rounded-lg p-4 mb-6 space-y-2">
              <p><strong>{t('תאריך משלוח:', 'Delivery Date:')}</strong> {orderDetails.deliveryDate}</p>
              <p><strong>{t('שעת משלוח:', 'Delivery Time:')}</strong> {orderDetails.deliveryTime}</p>
              <p><strong>{t('כתובת:', 'Address:')}</strong> {orderDetails.address}, {orderDetails.city}</p>
              <p><strong>{t('אמצעי תשלום:', 'Payment Method:')}</strong> {
                orderDetails.paymentMethod === 'cash' ? t('מזומן', 'Cash') :
                orderDetails.paymentMethod === 'bit' ? 'Bit' : 'PayBox'
              }</p>
            </div>

            <p className="text-gray-600 mb-6">
              {t(
                'נשלח אליך אישור בהקדם למייל ולטלפון. תודה שבחרת בנו!',
                'Confirmation will be sent to your email and phone shortly. Thank you for choosing us!'
              )}
            </p>

            {(orderDetails.paymentMethod === 'bit' || orderDetails.paymentMethod === 'paybox') && (
              <button
                onClick={handlePayment}
                className="w-full py-3 bg-chinese-red text-white rounded-lg font-semibold hover:bg-chinese-darkRed transition-colors mb-3"
              >
                {t('המשך לתשלום', 'Proceed to Payment')}
              </button>
            )}

            <button
              onClick={handleClose}
              className="w-full py-3 bg-gray-200 text-gray-800 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
            >
              {t('סגור', 'Close')}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
