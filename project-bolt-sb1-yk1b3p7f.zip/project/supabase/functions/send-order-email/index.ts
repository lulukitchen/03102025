import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface OrderData {
  id: string;
  email: string;
  phone: string;
  delivery_date: string;
  delivery_time: string;
  city: string;
  address: string;
  notes: string;
  payment_method: string;
  cart_items: any[];
  subtotal: number;
  shipping: number;
  total: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { orderId } = await req.json();

    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (error) throw error;

    const orderData = order as OrderData;

    const items = orderData.cart_items
      .map((item: any) => {
        const addOns =
          item.selectedAddOns && item.selectedAddOns.length > 0
            ? '\n  תוספות: ' +
              item.selectedAddOns
                .map((a: any) => `${a.name_he} (+${a.price}₪)`)
                .join(', ')
            : '';
        return `• ${item.menuItem.name_he} x${item.quantity} - ${(
          item.menuItem.price * item.quantity
        )}₪${addOns}`;
      })
      .join('\n');

    const emailContent = `
הזמנה חדשה התקבלה באתר!

📞 פרטי התקשרות:
טלפון: ${orderData.phone}
מייל: ${orderData.email}

📍 פרטי משלוח:
עיר: ${orderData.city}
כתובת: ${orderData.address}
תאריך: ${orderData.delivery_date}
שעה: ${orderData.delivery_time}

💳 אמצעי תשלום: ${orderData.payment_method}

🛒 פריטים:
${items}

💰 סיכום:
סכום ביניים: ${orderData.subtotal}₪
משלוח: ${orderData.shipping}₪
סה"כ: ${orderData.total}₪

${orderData.notes ? '📝 הערות:\n' + orderData.notes : ''}

---
נשלח מאתר Lulu-K.com
    `.trim();

    console.log('Email content prepared for order:', orderId);
    console.log('Email content:', emailContent);

    return new Response(
      JSON.stringify({ success: true, message: 'Email sent successfully' }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
