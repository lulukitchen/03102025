/*
  # Create Lulu-K Database Schema

  1. New Tables
    - `orders`
      - `id` (uuid, primary key)
      - `email` (text)
      - `phone` (text)
      - `delivery_date` (date)
      - `delivery_time` (text)
      - `city` (text)
      - `address` (text)
      - `notes` (text)
      - `payment_method` (text)
      - `cart_items` (jsonb) - stores the cart items
      - `subtotal` (numeric)
      - `shipping` (numeric)
      - `total` (numeric)
      - `status` (text) - pending, confirmed, completed, cancelled
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `contacts`
      - `id` (uuid, primary key)
      - `name` (text)
      - `phone` (text)
      - `email` (text, optional)
      - `preferred_date` (text, optional)
      - `preferred_time` (text, optional)
      - `message` (text)
      - `status` (text) - new, contacted, resolved
      - `created_at` (timestamptz)
    
    - `reviews`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text, optional)
      - `rating` (integer) - 1 to 5
      - `review_he` (text)
      - `review_en` (text, optional)
      - `status` (text) - pending, approved, rejected
      - `is_visible` (boolean) - for displaying on site
      - `created_at` (timestamptz)
    
    - `menu_items`
      - `id` (text, primary key)
      - `name_he` (text)
      - `name_en` (text)
      - `description_he` (text)
      - `description_en` (text)
      - `price` (numeric)
      - `image_url` (text)
      - `category` (text)
      - `is_available` (boolean)
      - `add_ons` (jsonb) - optional add-ons
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `delivery_areas`
      - `id` (uuid, primary key)
      - `city` (text)
      - `streets` (jsonb) - array of street names
      - `is_active` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access to menu_items and delivery_areas
    - Add policies for authenticated insert to orders, contacts, reviews
    - Add admin policies for managing data
*/

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  phone text NOT NULL,
  delivery_date date NOT NULL,
  delivery_time text NOT NULL,
  city text NOT NULL,
  address text NOT NULL,
  notes text DEFAULT '',
  payment_method text NOT NULL,
  cart_items jsonb NOT NULL,
  subtotal numeric(10,2) NOT NULL,
  shipping numeric(10,2) NOT NULL,
  total numeric(10,2) NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create contacts table
CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  email text DEFAULT '',
  preferred_date text DEFAULT '',
  preferred_time text DEFAULT '',
  message text NOT NULL,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text DEFAULT '',
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_he text NOT NULL,
  review_en text DEFAULT '',
  status text DEFAULT 'pending',
  is_visible boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create menu_items table
CREATE TABLE IF NOT EXISTS menu_items (
  id text PRIMARY KEY,
  name_he text NOT NULL,
  name_en text NOT NULL,
  description_he text DEFAULT '',
  description_en text DEFAULT '',
  price numeric(10,2) NOT NULL,
  image_url text DEFAULT '',
  category text NOT NULL,
  is_available boolean DEFAULT true,
  add_ons jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create delivery_areas table
CREATE TABLE IF NOT EXISTS delivery_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  city text NOT NULL UNIQUE,
  streets jsonb NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_areas ENABLE ROW LEVEL SECURITY;

-- Policies for orders (anyone can insert, but only view their own)
CREATE POLICY "Anyone can create orders"
  ON orders FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can view own orders by email"
  ON orders FOR SELECT
  TO anon
  USING (email = current_setting('request.jwt.claims', true)::json->>'email');

-- Policies for contacts (anyone can insert)
CREATE POLICY "Anyone can create contacts"
  ON contacts FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policies for reviews (anyone can insert, only approved visible)
CREATE POLICY "Anyone can create reviews"
  ON reviews FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can view approved reviews"
  ON reviews FOR SELECT
  TO anon
  USING (is_visible = true AND status = 'approved');

-- Policies for menu_items (public read)
CREATE POLICY "Anyone can view available menu items"
  ON menu_items FOR SELECT
  TO anon
  USING (is_available = true);

-- Policies for delivery_areas (public read)
CREATE POLICY "Anyone can view active delivery areas"
  ON delivery_areas FOR SELECT
  TO anon
  USING (is_active = true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(email);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_reviews_visible ON reviews(is_visible, status);
CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category);
CREATE INDEX IF NOT EXISTS idx_delivery_areas_city ON delivery_areas(city);